BEGIN Whilesimple
READ(i),
  i := 0,
  WHILE (i > 5) DO
    i := i + 1,
  END,
  PRINT(i),
END
