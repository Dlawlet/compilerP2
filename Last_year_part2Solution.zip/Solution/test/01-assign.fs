BEGIN Assign
x := 1+2,
END
