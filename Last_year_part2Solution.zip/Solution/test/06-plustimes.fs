BEGIN Plustimes
a := 3+3*4,
b := 3*3+4,
END
