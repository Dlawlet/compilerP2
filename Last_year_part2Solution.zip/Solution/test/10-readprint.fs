BEGIN Readprint
READ(x),
PRINT(x),
END
