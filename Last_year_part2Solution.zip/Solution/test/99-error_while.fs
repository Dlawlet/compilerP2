BEGIN Errorwhile
  WHILE (x = 1) DO
    x := 0,
END
