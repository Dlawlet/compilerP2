BEGIN Assoc
a := 2+3+4,
END
