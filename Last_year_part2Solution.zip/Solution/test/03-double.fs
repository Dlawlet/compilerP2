BEGIN Doubleneg
a := --2,
END
