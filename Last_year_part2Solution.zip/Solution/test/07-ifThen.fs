BEGIN Ifthen
  y := 0,
  x := 1,
  IF (x = 1) THEN
  y := 2,
  END,
END
