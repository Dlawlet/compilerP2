BEGIN Voidifthen %% This should compile %%
READ(x),
  x := 1,
  IF (x = 1) THEN
  END,
END
